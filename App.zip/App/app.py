import os
import flask

from flask import Flask, render_template, request, jsonify
from utils import *
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route("/")
def hello():
    return render_template('upload.html')

@app.route("/upload", methods=['GET'])
def upload():
    return render_template('upload.html')

@app.route("/show_result", methods=['POST'])
def result():
   filename, filepath_comp, status = save_file()
   if status == 'success':
       text = convert2text(filename, filepath_comp)
   else:
       return 'Resume not saved, pdf version not recognized'
   results = run_ner_model(text)
   result_dict = {}
   grand_list = []
   index = 0
   for result in results:
       #json_result={}
       #json_result = jsonify(result)
       result_dict[index] = result
       #grand_list.append(result)
       index = index + 1
   #col_names = result.keys()
   json_result = jsonify(result_dict)
   #print(json_result)
   #return render_template('json_table.html',records=result,colnames=col_names)
   # return str(grand_list)
   return json_result


@app.route("/show_result1", methods=['POST'])
def result1():
   filename, filepath_comp, status = save_file()
   if status == 'success':
       text = convert2text(filename, filepath_comp)
   else:
       return 'Resume not saved, pdf version not recognized'
   results = run_ner_model(text)
   result_dict = {}
   index = 0
   for result in results:
       result_dict[index] = result
       index = index + 1
   json_result = jsonify(result_dict)
   return json_result

if __name__ == '__main__':
    app.run(debug=True)