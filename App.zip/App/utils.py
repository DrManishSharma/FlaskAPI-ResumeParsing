import spacy
import fitz
import os
from flask import Flask, request

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

nlp =spacy.load('en_core_web_sm')
custom_ner_model = spacy.load('./model/nlp_model_20210106')

def save_file():
    filepath = os.path.join(APP_ROOT, 'data','input_data')
    if not os.path.isdir(filepath):
        os.mkdir(filepath)
    #file = request.files.get('file')
    files = request.files.getlist('file')
    filename = []
    filepath_comp = []
    for f in files:
        filename.append(f.filename)
        filepath_comp.append(os.path.join(filepath,f.filename))
        f.save(os.path.join(filepath,f.filename))
    return filename, filepath_comp,'success'

def convert2text(filename, filepath_comp):
    tx = []
    for i in range(len(filepath_comp)):
        doc = fitz.open(filepath_comp[i])
        text = ""
        for page in doc:
            text = text + str(page.getText())
        tx.append(" ".join(text.split('\n')))
    return tx

# def convert2text(filename, filepath_comp):
#     doc = fitz.open(filepath_comp)
#     text = ""
#     for page in doc:
#         text = text + str(page.getText())
#     tx = " ".join(text.split('\n'))
#     return tx

def run_ner_model(text):
    results = []
    for i in range(len(text)):
        doc = custom_ner_model(text[i])
        result = {}
        for ent in doc.ents:
            result[ent.label_.upper()] = ent.text
        results.append(result)
    return results

# def run_ner_model(text):
#     doc = custom_ner_model(text)
#     result = {}
#     for ent in doc.ents:
#         result[ent.label_.upper()] = ent.text
#     return result